import React, { Suspense, lazy } from 'react';
import { Routes, Route } from 'react-router-dom';
import Layout from './components/layout/Layout.jsx';

const HomePage = lazy(() => import('./pages/HomePage.jsx'));
const AboutPage = lazy(() => import('./pages/AboutPage.jsx'));
const ProjectsPage = lazy(() => import('./pages/ProjectsPage.jsx'));
const EventsPage = lazy(() => import('./pages/EventsPage.jsx'));
const MediaPage = lazy(() => import('./pages/MediaPage.jsx'));
const ContactPage = lazy(() => import('./pages/ContactPage.jsx'));

function App() {
  return (
    <Layout>
      <Suspense
        fallback={
          <div className="min-h-[60vh] flex items-center justify-center text-sm text-gray-300">
            <span className="animate-pulse rounded-full border border-zcp-gray/60 px-4 py-2 uppercase tracking-[0.25em]">
              Loading a0page...
            </span>
          </div>
        }
      >
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/about" element={<AboutPage />} />
          <Route path="/projects" element={<ProjectsPage />} />
          <Route path="/events" element={<EventsPage />} />
          <Route path="/media" element={<MediaPage />} />
          <Route path="/contact" element={<ContactPage />} />
        </Routes>
      </Suspense>
    </Layout>
  );
}

export default App;
