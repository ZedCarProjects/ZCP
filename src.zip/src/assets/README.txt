Add your high-resolution car photos, event posters and logos in this folder.

Example suggestions:
- hero-track-night.jpg
- build-vip-mark2.jpg
- build-track-s13.jpg
- build-rally-gti.jpg
- event-lusaka-night-meet.jpg

Update the imports in components if you decide to switch from remote image URLs to local files.
