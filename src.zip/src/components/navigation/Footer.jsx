import React from 'react';
import { socialLinks } from '../../config/social.js';
import { FaWhatsapp, FaFacebookF, FaInstagram, FaYoutube } from 'react-icons/fa';

function Footer() {
  return (
    <footer className="border-t border-zcp-gray/80 bg-black/95">
      <div className="section-padding pt-8 pb-8 grid gap-8 lg:grid-cols-[1.2fr,1fr] items-start">
        <div>
          <p className="section-heading">The New Wave of Zambian Motorsport</p>
          <p className="text-xl sm:text-2xl md:text-3xl font-display font-semibold">
            Built by drivers, tuners and storytellers pushing Zambian car culture forward.
          </p>
          <div className="mt-6 flex flex-wrap items-center gap-4 text-xs uppercase tracking-[0.25em] text-gray-400">
            <span className="inline-flex items-center gap-2">
              <span className="h-1.5 w-1.5 rounded-full bg-zcp-red animate-pulse"></span>
              Street  b7 Pad  b7 Strip
            </span>
          </div>
        </div>

        <div className="card-surface rounded-2xl p-5 sm:p-7 flex flex-col gap-3 text-sm">
          <p className="text-xs font-semibold uppercase tracking-[0.25em] text-zcp-yellow">
            Stay Ahead of the Grid
          </p>
          <h3 className="font-display text-xl sm:text-2xl font-semibold">
            Join the official Zed Car Projects WhatsApp channel.
          </h3>
          <p className="text-xs sm:text-sm text-gray-300">
            Get instant updates on meets, Autofest announcements, feature builds and track days, straight
            to your phone.
          </p>
          <a
            href={socialLinks.whatsappChannel}
            target="_blank"
            rel="noreferrer"
            className="btn-primary mt-2 text-[11px] w-fit inline-flex items-center gap-2"
          >
            <FaWhatsapp className="h-4 w-4" aria-hidden="true" />
            <span>Join WhatsApp Channel</span>
          </a>
        </div>
      </div>

      <div className="px-4 sm:px-6 lg:px-10 xl:px-16 py-4 flex flex-col sm:flex-row items-center justify-between gap-3 text-[11px] text-gray-400">
        <p>© {new Date().getFullYear()} Zed Car Projects. All rights reserved.</p>
        <div className="flex items-center gap-4 text-[12px]">
          <a
            href={socialLinks.facebook}
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-1 hover:text-zcp-yellow"
          >
            <FaFacebookF className="h-3.5 w-3.5" aria-hidden="true" />
            <span>Facebook</span>
          </a>
          <a
            href={socialLinks.instagram}
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-1 hover:text-zcp-yellow"
          >
            <FaInstagram className="h-3.5 w-3.5" aria-hidden="true" />
            <span>Instagram</span>
          </a>
          <a
            href={socialLinks.youtubeChannel}
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-1 hover:text-zcp-yellow"
          >
            <FaYoutube className="h-3.5 w-3.5" aria-hidden="true" />
            <span>YouTube</span>
          </a>
        </div>
      </div>
    </footer>
  );
}

export default Footer;
