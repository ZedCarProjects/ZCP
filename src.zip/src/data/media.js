import media1 from '../assets/MEDIA 1.jpg';
import media2 from '../assets/MEDIA 2.jpg';
import media3 from '../assets/MEDIA 3.jpg';
import media4 from '../assets/MEDIA 4.jpg';
import media5 from '../assets/MEDIA 5.jpg';
import media6 from '../assets/MEDIA 6.jpg';
import media7 from '../assets/MEDIA 7.jpg';
import media8 from '../assets/MEDIA 8.jpg';
import media9 from '../assets/MEDIA 9.jpg';
import media10 from '../assets/MEDIA 10.jpg';
import media11 from '../assets/MEDIA 11.jpg';
import media12 from '../assets/MEDIA 12.jpg';
import media13 from '../assets/MEDIA 13.jpg';
import media14 from '../assets/MEDIA 14.jpg';
import media15 from '../assets/MEDIA 15.jpg';
import media16 from '../assets/MEDIA 16.jpg';
import media17 from '../assets/MEDIA 17.jpg';
import media18 from '../assets/MEDIA 18.jpg';
import media19 from '../assets/MEDIA 19.jpg';
import media20 from '../assets/MEDIA 20.jpg';
import media21 from '../assets/MEDIA 21.jpg';
import media22 from '../assets/MEDIA 22.jpg';
import media23 from '../assets/MEDIA 23.jpg';
import media24 from '../assets/MEDIA 24.jpg';
import media25 from '../assets/MEDIA 25.jpg';

export const photoGallery = [
  { id: 'media-1', image: media1 },
  { id: 'media-7', image: media7 },
  { id: 'media-3', image: media3 },
  { id: 'media-12', image: media12 },
  { id: 'media-20', image: media20 },
  { id: 'media-9', image: media9 },
  { id: 'media-15', image: media15 },
  { id: 'media-5', image: media5 },
  { id: 'media-22', image: media22 },
  { id: 'media-2', image: media2 },
  { id: 'media-25', image: media25 },
  { id: 'media-18', image: media18 },
  { id: 'media-10', image: media10 },
  { id: 'media-14', image: media14 },
  { id: 'media-4', image: media4 },
  { id: 'media-19', image: media19 },
  { id: 'media-11', image: media11 },
  { id: 'media-8', image: media8 },
  { id: 'media-21', image: media21 },
  { id: 'media-6', image: media6 },
  { id: 'media-24', image: media24 },
  { id: 'media-13', image: media13 },
  { id: 'media-23', image: media23 },
  { id: 'media-16', image: media16 },
  { id: 'media-17', image: media17 },
];

export const videos = [
  // Replace these IDs with specific videos from
  // https://www.youtube.com/channel/UCQsaeonyy8lnkyPHO7phWvg
];
